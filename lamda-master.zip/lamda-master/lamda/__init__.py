# Copyright 2022 rev1si0n (ihaven0emmail@gmail.com). All rights reserved.
#
# Distributed under MIT license.
# See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
__version__ = "3.0"
__build__ = 10
